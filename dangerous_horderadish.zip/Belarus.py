import pygame
from pygame import *
from random import randint, choice


class Player(pygame.sprite.Sprite):
    def __init__(self):
        self.x, self.y = w // 2, h // 2
        self.width, self.height = 100, 100
        self.player_stand = pygame.image.load('player_s0.png')
        self.speed = 15
        self.animCount = 0
        self.clock = pygame.time.Clock()
        self.hit = False
        self.life = True

        self.key_S = [pygame.image.load('player_s0.png'),
                      pygame.image.load('player_s1.png'), pygame.image.load('player_s2.png')]
        self.key_D = [pygame.image.load('player_d0.png'),
                      pygame.image.load('player_d1.png'), pygame.image.load('player_d2.png')]
        self.key_A = [pygame.image.load('player_a0.png'),
                      pygame.image.load('player_a1.png'), pygame.image.load('player_a2.png')]
        self.key_W = [pygame.image.load('player_w0.png'),
                      pygame.image.load('player_w1.png'), pygame.image.load('player_w2.png')]

        self.image = self.player_stand
        self.rect = self.image.get_rect()
        self.vector = [0, 0]
    # здесь задаются основыне переменные класса игрока

    def base(self):
        pygame.time.Clock().tick(60)
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                pygame.quit()

        if self.life:
            keys = pygame.key.get_pressed()
            if keys[pygame.K_d] and self.x + self.width < w:
                self.x += self.speed
                self.vector[0] = 1
            elif keys[pygame.K_a] and self.x > 0:
                self.x -= self.speed
                self.vector[0] = -1
            else:
                self.vector[0] = 0

            if keys[pygame.K_s] and self.y + self.height < h:
                self.y += self.speed
                self.vector[1] = -1
            elif keys[pygame.K_w] and self.y > 0:
                self.y -= self.speed
                self.vector[1] = 1
            else:
                self.vector[1] = 0

            if keys[pygame.K_h]:
                self.hit = True
                self.width, self.height = 500, 500
            else:
                self.width, self.height = 100, 100
                self.hit = False

            self.animation()
    # в этой функции записан механизм работы игрока

    def animation(self):
        pygame.init()
        screen.fill((10, 85, 10))
        pygame.display.flip()
        pygame.display.update()
        if self.life:
            if self.animCount + 1 >= 12:
                self.animCount = 0

            if self.vector == [0, -1]:
                self.image = self.key_S[self.animCount // 4]
                self.animCount += 1
                if self.hit:
                    self.image = pygame.image.load('player_s_hit.png')
            elif self.vector[0] == 1:
                self.image = self.key_D[self.animCount // 4]
                if self.hit:
                    self.image = pygame.image.load('player_d_hit1.png')
                    self.image = pygame.image.load('player_d_hit2.png')
                self.animCount += 1
            elif self.vector[0] == -1:
                self.image = self.key_A[self.animCount // 4]
                self.animCount += 1
                if self.hit:
                    self.image = pygame.image.load('player_a_hit1.png')
                    self.image = pygame.image.load('player_a_hit2.png')
            elif self.vector == [0, 1]:
                self.image = self.key_W[self.animCount // 4]
                self.animCount += 1
                if self.hit:
                    self.image = pygame.image.load('player_w_hit.png')
            else:
                self.image = self.player_stand
            font = pygame.font.Font(None, 60)
            self.text = font.render(str(time // 100), True, (255, 255, 255))
            self.rect.move(self.speed * self.vector[0], self.speed * self.vector[1])
            screen.blit(self.text, (10, 10))
            self.image = pygame.transform.scale(self.image, (150, 150))
            screen.blit(self.image, (self.x, self.y))
    # здесь написан код, анимирующий игрока


class Bug(pygame.sprite.Sprite):
    def __init__(self):
        self.x, self.y = choice([randint(w, w + 100), randint(-100, 0)]), choice(
            [randint(h, h + 100), randint(-100, 0)])
        self.width, self.height = 100, 100
        self.speed = 5
        self.image = pygame.image.load('bug_front.png')
        self.animCount = 0

        self.right = [pygame.image.load('bug_side_right0.png'),
                      pygame.image.load('bug_side_right1.png'), pygame.image.load('bug_side_right2.png')]
        self.left = [pygame.image.load('bug_side_left0.png'),
                      pygame.image.load('bug_side_left1.png'), pygame.image.load('bug_side_left2.png')]
        self.back = [pygame.image.load('bug_back1.png'), pygame.image.load('bug_back2.png')]
        self.front = [pygame.image.load('bug_front1.png'), pygame.image.load('bug_front2.png')]

        self.rect = self.image.get_rect()
        self.vector = [0, 0]
        self.clock = pygame.time.Clock()
        self.life = True
    # здесь записаны основные переменные класса жука

    def dead(self):
        self.life = False
        self.image = pygame.image.load('bug_dead.png')
        screen.blit(self.image, (self.x, self.y))
    # здесь прорисовываются злые души колорадских жуков за мгновение до того, как они уйдут под землю в преисподнюю


    def base(self):
        if self.life and player.life:
            if player.x < self.x:
                self.x -= self.speed
                self.vector[0] = -1
            elif player.x > self.x:
                self.x += self.speed
                self.vector[0] = 1
            else:
                self.vector[0] = 0

            if player.y < self.y:
                self.y -= self.speed
                self.vector[1] = -1
            elif player.y > self.y:
                self.y += self.speed
                self.vector[1] = 1
            else:
                self.vector[1] = 0

            if player.x < self.x < player.x + player.width and player.y < self.y < player.y + player.height and\
                    not player.hit:
                player.life = False

            if player.y == self.y:
                if player.vector[0] == 1 and 300 < self.x - player.x <= 600 and player.hit:
                    self.dead()
                elif player.vector[0] == -1 and -300 <= self.x - player.x < 0 and player.hit:
                    self.dead()
            if player.y == self.y:
                if player.vector[1] == 1 and 300 < self.y - player.y <= 600 and player.hit:
                    self.dead()
                elif player.vector[1] == -1 and -300 <= self.y - player.y < 0 and player.hit:
                    self.dead()

            self.animation()
    # здесь прописан механизм работы жука


    def animation(self):
        pygame.init()
        pygame.display.flip()
        if self.life and player.life:
            if self.animCount + 1 >= 12:
                self.animCount = 0

            if self.vector == [0, -1]:
                self.image = self.back[self.animCount // 6]
                self.animCount += 1
            elif self.vector[0] == 1:
                self.image = self.right[self.animCount // 4]
                self.animCount += 1
            elif self.vector[0] == -1:
                self.image = self.left[self.animCount // 4]
                self.animCount += 1
            elif self.vector == [0, 1]:
                self.image = self.front[self.animCount // 6]
                self.animCount += 1

            self.rect.move(self.speed * self.vector[0], self.speed * self.vector[1])
            self.image = pygame.transform.scale(self.image, (150, 150))
            screen.blit(self.image, (self.x, self.y))
    # тут я анімував клятого колорадського жука


def level1():
    global bug1, bug2, bug3, bug4, time

    while time != 0 and player.life:
        player.base()
        bug1.base()
        bug2.base()
        bug3.base()
        bug4.base()
        if not bug1.life:
            bug1 = Bug()

        if not bug2.life:
            bug2 = Bug()

        if not bug3.life:
            bug3 = Bug()

        if not bug4.life:
            bug4 = Bug()

        if not player.life:
            screen.blit(pygame.image.load('game_over.png'), (0, 0))
            font = pygame.font.Font(None, 60)
            text = font.render('Продержался ' + str(time // 1000) + ' секунд', True, (255, 255, 255))
            screen.blit(text, (200, 600))
        time -= 4

    for ev in pygame.event.get():
        if ev.type == pygame.QUIT:
            pygame.quit()

    # тута прописан первый уровень


if __name__ == '__main__':
    pygame.init()
    size = w, h = 1500, 700
    screen = pygame.display.set_mode(size)
    splash_screen = pygame.transform.scale(pygame.image.load('splash_screen.png'), (size))
    screen.blit(splash_screen, (0, 0))
    pygame.display.set_caption('Опасный')
    pygame.display.flip()
    player = Player()
    bug1 = Bug()
    bug2 = Bug()
    bug3 = Bug()
    bug4 = Bug()
    time = 9000
    start = False
    while not start:
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                pygame.quit()
            elif ev.type == pygame.KEYDOWN:
                start = True
    while start:
        pygame.init()
        pygame.display.flip()

        level1()
        pygame.display.update()

    # а здесь запускается сама программа
